/** 
 * @package     Minima
 * @author      Henrik Hussfelt, Marco Barbosa
 * @copyright   Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 *				This Class is mainly for code-readability.
 */

var MinimaClass = new Class({
    
    Implements: [Options],

    options: {
    },

    elements: {
        systemMessage : null,
        jformTitle    : null
    },    

    // minima node
    minima : null,

    initialize: function(options, elements){
       // set the main node for DOM selection
        this.minima = document.id(this.options.minima) || document.id('minima');
        // Set options
        this.setOptions(options);
        // Set elements
        this.elements = elements;
    },

    showSystemMessage: function() {
        // system-message fade
        if (this.elements.systemMessage && this.elements.systemMessage.getElement("ul li:last-child")) {
            var _this = this,
                hideAnchor = new Element('a', {
                'href': '#',
                'id': 'hide-system-message',
                'html': 'hide',
                'events': {
                    'click': function(e){
                        _this.elements.systemMessage.dissolve({duration: 'short'})
                    }
                }
            });
            // inject hideAnchor in the system-message container
            this.elements.systemMessage.show().getElement("ul li:last-child").adopt(hideAnchor);
        };
    },

    dynamicTitle: function() {        
        
        // save the h2 element
        var h2Title     = this.minima.getElement('.pagetitle h2'),
            jformAlias  = $('jform_alias'),
            _this       = this;

        // change the h2 title dynamically
        // set the title of the page with the jform_title
        if(this.elements.jformTitle.get("value") != "") h2Title.set('html', this.elements.jformTitle.get("value"));
        
        // change while typing it
        this.elements.jformTitle.addEvent('keyup', function(event){
            // show h2 with the title typed
            if (_this.elements.jformTitle.get("value") != ""){
               h2Title.set('html', this.get("value"));
            }
            //fix alias automatically, removing extra chars, all lower cased
            // but only if it's a new content
            if (_this.minima.hasClass('no-id') && jformAlias) {
                jformAlias.set( 'value', this.get("value").standardize().replace(/\s+/g, '-').replace(/[^-\w]+/g, '').toLowerCase() );
            }
        });
        
    },

    makeRowsClickable: function() {
        // get the toggle element
        var toggle = $$('input[name=checkall-toggle]');        
        // add the real click event
        toggle.addEvent('click', function(){
            var rows = $$('.adminlist tbody tr');
            rows.toggleClass('selected');
        });

        $$('.adminlist tbody tr input[type=checkbox]').each(function(element){
                
            var parent = element.getParent('tr'), // get parent                
                boxchecked = $$('input[name=boxchecked]'); // get boxchecked

            // add click event
            element.addEvent('click', function(event){
                event && event.stopPropagation();

                if (element.checked) {
                    parent.addClass('selected');
                } else {
                    parent.removeClass('selected');
                }
            });

            // add click event
            parent.addEvent('click', function(){
                if (element.checked) {
                    element.set('checked', false);
                    boxchecked.set('value',0)
                }else{
                    element.set('checked', true);
                    boxchecked.set('value', 1);
                }
                element.fireEvent('click');
            });

        });

        // highlight the sorting column
        $$('.adminlist th img').getParent('th').addClass('active');
    }
    
});    /**
 * @version     0.8
 * @package     Minima
 * @author      Marco Barbosa
 * @copyright   Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// Raphael.colorwheel
(function(a){a.colorwheel=function(g,k,i,j,h){return new b(g,k,i,j,h)};var e=Math.PI;function f(g,h){return(g<0)*180+Math.atan(-h/-g)*180/e}var d=document,c=window;var b=function(u,p,F,j,g){F=F||200;var q=3*F/200,w=F/200,z=1.6180339887,J=e*F/5,O=F/20,o=F/2,D=2*F/200,A=this;var v=1,k=1,G=1,C=F-(O*4);var E=g?a(g,F,F):a(u,p,F,F),m=C/6+O*2+D,n=C*2/3-D*2;w<1&&(w=1);q<1&&(q=1);var N=e/2-e*2/J*1.3,l=o-D,M=o-D-O*2,I=["M",o,D,"A",l,l,0,0,1,l*Math.cos(N)+l+D,l-l*Math.sin(N)+D,"L",M*Math.cos(N)+l+D,l-M*Math.sin(N)+D,"A",M,M,0,0,0,o,D+O*2,"z"].join();for(var K=0;K<J;K++){E.path(I).attr({stroke:"none",fill:"hsb("+K*(360/J)+", 100, 100)",rotation:[(360/J)*K,o,o]})}E.path(["M",o,D,"A",l,l,0,1,1,o-1,D,"l1,0","M",o,D+O*2,"A",M,M,0,1,1,o-1,D+O*2,"l1,0"]).attr({"stroke-width":q,stroke:"#fff"});A.cursorhsb=E.set();var L=O*2+2;A.cursorhsb.push(E.rect(o-L/z/2,D-1,L/z,L,3*F/200).attr({stroke:"#000",opacity:0.5,"stroke-width":q}));A.cursorhsb.push(A.cursorhsb[0].clone().attr({stroke:"#fff",opacity:1,"stroke-width":w}));A.ring=E.path(["M",o,D,"A",l,l,0,1,1,o-1,D,"l1,0M",o,D+O*2,"A",M,M,0,1,1,o-1,D+O*2,"l1,0"]).attr({fill:"#000",opacity:0,stroke:"none"});A.main=E.rect(m,m,n,n).attr({stroke:"none",fill:"#f00",opacity:1});A.main.clone().attr({stroke:"none",fill:"0-#fff-#fff",opacity:0});A.square=E.rect(m-1,m-1,n+2,n+2).attr({r:2,stroke:"#fff","stroke-width":q,fill:"90-#000-#000",opacity:0,cursor:"crosshair"});A.cursor=E.set();A.cursor.push(E.circle(o,o,O/2).attr({stroke:"#000",opacity:0.5,"stroke-width":q}));A.cursor.push(A.cursor[0].clone().attr({stroke:"#fff",opacity:1,"stroke-width":w}));A.H=A.S=A.B=1;A.raphael=E;A.size2=o;A.wh=n;A.x=u;A.xy=m;A.y=p;A.ring.drag(function(r,i,h,s){A.docOnMove(r,i,h,s)},function(h,i){A.hsbOnTheMove=true;A.setH(h-A.x-A.size2,i-A.y-A.size2)},function(){A.hsbOnTheMove=false});A.square.drag(function(r,i,h,s){A.docOnMove(r,i,h,s)},function(h,i){A.clrOnTheMove=true;A.setSB(h-A.x,i-A.y)},function(){A.clrOnTheMove=false});A.color(j||"#f00");this.onchanged&&this.onchanged(this.color())};b.prototype.setH=function(g,j){var i=f(g,j),h=i*e/180;this.cursorhsb.rotate(i+90,this.size2,this.size2);this.H=(i+90)/360;this.main.attr({fill:"hsb("+this.H+",1,1)"});this.onchange&&this.onchange(this.color())};b.prototype.setSB=function(g,h){g<this.size2-this.wh/2&&(g=this.size2-this.wh/2);g>this.size2+this.wh/2&&(g=this.size2+this.wh/2);h<this.size2-this.wh/2&&(h=this.size2-this.wh/2);h>this.size2+this.wh/2&&(h=this.size2+this.wh/2);this.cursor.attr({cx:g,cy:h});this.B=1-(h-this.xy)/this.wh;this.S=(g-this.xy)/this.wh;this.onchange&&this.onchange(this.color())};b.prototype.docOnMove=function(i,h,g,j){if(this.hsbOnTheMove){this.setH(g-this.x-this.size2,j-this.y-this.size2)}if(this.clrOnTheMove){this.setSB(g-this.x,j-this.y)}};b.prototype.remove=function(){this.raphael.remove();this.color=function(){return false}};b.prototype.color=function(h){if(h){h=a.getRGB(h);h=a.rgb2hsb(h.r,h.g,h.b);var i=h.h*360;this.H=h.h;this.S=h.s;this.B=h.b;this.cursorhsb.rotate(i,this.size2,this.size2);this.main.attr({fill:"hsb("+this.H+",1,1)"});var g=this.S*this.wh+this.xy,j=(1-this.B)*this.wh+this.xy;this.cursor.attr({cx:g,cy:j});return this}else{return a.hsb2rgb(this.H,this.S,this.B).hex}}})(window.Raphael);

window.addEvent('domready', function() {

    var out = document.getElementById('jform_params_templateColor'),
        reg = /^#(.)\1(.)\2(.)\3$/,
        inputDarkerColor = document.getElementById('jform_params_darkerColor');

    // for stylying and positioning
    $$('.fltrt')[0].addClass('templateBasic');

    // set container
    var wheelContainer = new Element('div#colorWheel');

    // create colorwheel
    var colorwheel = Raphael.colorwheel( out.getPosition().x+150, out.getPosition().y-50, 150, out.get('value') );

    // updating the input background
    out.style.background = out.value;

    // assigning onkey event handler
    out.onkeyup = function () {
        colorwheel.color(this.value);
        out.style.background = this.value;
        if(this.value.length >= 4 && this.value[0] == "#") updateColor(this.value);
        if(!this.value) updateColor("#2A94C8"); //7DBE30
    };

    // assigning onchange event handler
    colorwheel.onchange = function (clr) {
        out.value = clr.replace(reg, '#$1$2$3');
        out.style.background = clr;
        out.style.color = Raphael.rgb2hsb(clr).b < .5 ? "#fff" : "#000";
        updateColor(out.value);
    };

    // function to update the darker color
    var updateColor = function (value) {
        // create the darker color of value
        var darkerColor  = new Color(value).mix('#000', 15).rgbToHex();
        // associate to hidden input
        inputDarkerColor.set('value', darkerColor);
        // change header
        $('tophead').setStyles({
            background: out.value,
            background: "-webkit-gradient(linear, left top, left bottom, from("+out.value+"), to("+darkerColor+"))",
            backgroundImage: "-moz-linear-gradient(-90deg,"+out.value+","+darkerColor+")"
        });
        // change logo
        $('logo').setStyles({
            textShadow: "1px 1px 0 "+darkerColor+", -1px -1px 0 "+darkerColor+""
        });

    }

});
var MinimaFilterBarClass = new Class({

    Implements: [Options],

    options: {},

    // minima node
    minima: null,

    // labels statuses strings
    filterStatusLabels : {        
        "true": "Hide search & filters",
        "false":  "Show search & filters"
    },

    // boolean that tells if the filter is active or not
    isActive : false,

    // page title string
    pageTitle : "",

    // dom elements
    elements: {
        filterBar : null
    },
    
    // the filter elements
    filterSlide  : null,
    filterAnchor : null,

    // constructor
    initialize: function(options, elements, lang) {        
        // set the main node for DOM selection
        this.minima = $(this.options.minima) || $('minima');
        // set options
        this.setOptions(options);
        // set elements
        this.elements = elements;
        // set the labels
        if (lang.length) {
            this.setLabelsLanguage(lang['hideFilter'], lang['showFilter']);                
        }
    },

    // set the language
    setLabelsLanguage: function(hideFilter, showFilter) {        
        if (hideFilter.length && showFilter.length) {            
            this.filterStatusLabels['true']  = hideFilter;
            this.filterStatusLabels['false'] = showFilter;
        }
    },

    createSlideElements: function() {
        var _this = this;
        this.filterSlide  = new Fx.Slide(this.elements.filterBar).hide();
        this.filterAnchor = new Element('a', {
                                    'href': '#minima',
                                    'id': 'open-filter',
                                    'html': _this.filterStatusLabels['false'],                                    
                                    'events': {
                                        'click': function(e){
                                            var filterSearch = $('filter_search');
                                            e.stop();
                                            _this.filterSlide.toggle();
                                            this.toggleClass("active");                    
                                            if (this.hasClass("active") && filterSearch) {
                                                filterSearch.focus();
                                            }; 
                                            if ($('content-top').hasClass('fixed')) {
                                                window.scrollTo(0,0);
                                            };
                                        }
                                    }
                                });        
    },

    // put the new anchor in place
    fixAnchor: function() {
        this.minima.getElement('.pagetitle').grab(this.filterAnchor);        
    },

    // when filters change
    onFilterSelected: function() {
        var _this  = this;
        filterBar.getElements('input, select').each(function(el) {
            var value = el.get('value');
            if (value) {
                _this.isActive = true;
                _this.pageTitle += ( el.get('tag').toLowerCase() == "select" ) ?
                    el.getElement("option:selected").get("html").toLowerCase() + " " : _this.pageTitle += value.toLowerCase() + " ";
                _this.addFiltersToTitle();
            };
        });
    },

    // change title adding the filters as well
    addFiltersToTitle: function() {
        // and change <h2> showing the selected filters
        var h2Title = minima.getElement('.pagetitle h2');
        // if the string contains something
        if (this.pageTitle.length) {
            // change the h2 with the new string
            h2Title.set( 'html', h2Title.get('html') + "<em>( "+this.pageTitle+")</em>" );
        };
    },

    doFilterBar: function() {        
        var _this = this;
        // create the new elements necessary to work
        this.createSlideElements();
        // move anchor to proper place
        this.fixAnchor();
        // attach the listener to the inputs
        this.onFilterSelected();
        // do stuff if it's active
        if (this.isActive) {
            this.filterSlide.show(); 
            this.filterAnchor.set('html', this.filterStatusLabels[this.filterSlide.open]).addClass("active"); 
        };
        // toggle the css class and the status label (show/hide)
        this.filterSlide.addEvent('complete', function() {
            _this.filterAnchor.set('html', _this.filterStatusLabels[_this.filterSlide.open]);
        });
        // all prepared, show the filter-bar
        this.elements.filterBar.show();
        
    }

});/** 
 * @package     Minima
 * @author      Henrik Hussfelt, Marco Barbosa
 * @copyright   Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

var MinimaPanelClass = new Class({
    Implements: [Options],

    panelStatus: {
        'true': 'active',
        'false': 'inactive'
    },

    panel: null,

    options: {
        prev: '',
        next: '',
        panelList: '',
        panelPage: '',
        panelWrapper: '',
        toIncrement: 0,
        increment: 900
    },

    // minima node
    minima: null,

    // some private variables
    maxRightIncrement: null,
    panelSlide: null,
    numberOfExtensions: null,

    initialize: function(options){
        
        // set the main node for DOM selection
        this.minima = document.id(this.options.minima) || document.id('minima');
        
        // Set options
        this.setOptions(options);

        // Create a slide in this class scope
        this.panel = new Fx.Slide.Mine(this.options.panelWrapper, {
            mode: "vertical",
            transition: Fx.Transitions.Pow.easeOut
        }).hide();

        // Only execute code for tweening if there is a next-button
        if (this.options.next) {
            // Create the panel slide tween function
            this.panelSlide = new Fx.Tween( this.options.panelList, {duration: 500, transition: 'back:in:out'} );
            // how many extensions do we have
            this.numberOfExtensions = this.options.panelList.getElements("li").length;
            // increase the width basing on numberOfExtensions, allways divide by 9 because we have 9 extensions per page
            this.options.panelList.setStyle("width", Math.ceil(this.numberOfExtensions / 9) * this.options.increment );
            // dynamic max incrementation size (it depends on how many elements)
            //this.maxRightIncrement = ( this.options.increment * -( Math.ceil(this.numberOfExtensions / 9) ) ) + 900;
            this.maxRightIncrement = -Math.ceil(this.options.panelPage.getChildren().length*this.options.increment-this.options.increment);
            // Initiate showbuttons
            this.showButtons();
        };
    },

    doPrevious: function () {
        if(this.options.toIncrement < 0) {
            this.options.next.show();
            this.options.toIncrement += this.options.increment;
            this.panelSlide.pause();
            this.panelSlide.start('margin-left', this.options.toIncrement);
            // fix pagination
            this.options.panelPage.getFirst('.current').removeClass('current').getPrevious('li').addClass('current');
            // hide buttons if needed
            this.showButtons();
        }
    },

    doNext: function () {
        if(this.options.toIncrement > this.maxRightIncrement) {
            // Show previous
            this.options.prev.show();
            // Count what to increment
            this.options.toIncrement -= this.options.increment;
            // Paus slider
            this.panelSlide.pause();
            // Change marign
            this.panelSlide.start('margin-left', this.options.toIncrement);
            // fix pagination
            this.options.panelPage.getFirst('.current').removeClass('current').getNext('li').addClass('current');
            // hide buttons if needed
            this.showButtons();
        };
    },

    changeToPage: function(el) {
        // Get the page number
        var pageNumber = el.id.substr("panel-pagination-".length);
        // Paus the slidefunciton
        this.panelSlide.pause();
        // Change global toIncrement value
        this.options.toIncrement = Math.ceil(0-this.options.increment*pageNumber);
        // Execute slide
        this.panelSlide.start('margin-left', this.options.toIncrement);
        // Remove previous current class
        this.options.panelPage.getFirst('.current').removeClass('current');
        el.addClass('current');
        this.showButtons();
    },

    showButtons: function() {
        if (this.options.toIncrement == 0) {
            this.options.prev.hide();
        } else {
            this.options.prev.show();
        };
        if (this.options.toIncrement == this.maxRightIncrement) {
            this.options.next.hide();
        } else {
            this.options.next.show();
        };
    }
});/** 
 * @package     Minima
 * @author      Henrik Hussfelt, Marco Barbosa
 * @copyright   Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

var MinimaTabsClass = new Class({
        
    Implements: [Options],

    options: {
    },

    elements: {
        tabs     : null,
        content  : null
    },
        
    initialize: function(options, elements){
        // Set options
        this.setOptions(options);
        // Set elements
        this.elements = elements;
    },

    // move outside tabs the proper place
    moveTabs: function(el) {        
        // the #submenu should have a .minimaTabs class
        //this.elements.subMenu.addClass('minima-tabs');            
        // move the tbas to the right place
        // which is above the title and toolbar-box
        el.inject( $('content'),'top' );
    },

    // shows the first tab content
    showFirst: function() {
        // Show first
        this.elements.content.pick().removeClass('hide');
    },

    // hide all contents
    hideAllContent: function() {
        // Hide all
        this.elements.content.addClass('hide');
    },

    // attaches the tabs actions
    addTabsAction: function() {
        // save the context
        var _this = this;            
        // go through each tab and do the magic
        this.elements.tabs.each(function(tab, index){                
            tab.addEvents({
                click: function(e){                        
                    // Stop the event
                    e.stop();
                    // Remove class active from all tabs
                    _this.elements.tabs.removeClass('active');
                    // Add class to clicked element
                    _this.elements.tabs[index].addClass('active');
                    // Hide the content
                    _this.elements.content.addClass('hide');
                    // Add class to clicked elements content
                    _this.elements.content[index].removeClass('hide');
                }
            }); //end of tab.addEvents
        }); // end of tabs.each
    }
    
});/** 
 * @package     Minima
 * @author      Marco Barbosa
 * @copyright   Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

 MinimaToolbarClass = new Class({

    // implements
    Implements: [Options],

    // class options
    options: {
        'toolbar' : $('toolbar'), // toolbar parent
        'toolbarElements' : $$('.toolbar-list li a'), // list of the anchor elements
        'label' : null
    },

    // arrays
    bulkActionsArray: new Array(), // array with the actions
    bulkNonActionsArray: new Array(), // array with the other elements      
        
    // minima node
    minima : null,

    // initialize the class
    initialize: function(options){
        // set the main node for DOM selection
        this.minima = document.id(this.options.minima) || document.id('minima');
        // Set options
        this.setOptions(options);
    }, // end of initialize

    // function to be called to run the class
    doToolbar: function() {
        this.sortItems();
        this.fixToolbar();        
    }, // end of doToolbar

    // sort the items between actions and non actions
    sortItems: function() {  
        // save this for further reference      
        var _this = this;
        // if we have elements to sort
        if (this.options.toolbarElements.length) {
            // go through each of them
            this.options.toolbarElements.each(function(item) {
                // whatever has a 'if' clause in the onclick value is a bulk action
                if (item.get('onclick') != null && item.get('onclick').contains('if')) {                
                   _this.bulkActionsArray.push(item.getParent('li'));                
                } else if (item.get('class') != "divider") {
                   _this.bulkNonActionsArray.push(item.getParent('li'));
                }
            });
        }       
    }, // end of sortItems

    // fix the toolbar
    fixToolbar: function() {
        // save this for further reference
        var _this = this;
        // only proccess if we have more than one in bulkActionsArray
        if (this.bulkActionsArray.length > 1) {         
            // creating new elements            
            var 
                // actions <ul>
                bulkListChildren = new Element('ul#actions').hide(), 
                // create parent <li> that will toggle the new <ul>
                bulkListParent   = new Element('li', { 
                    'id': 'bulkActions',
                    'events': {
                        'click': function(event){
                            // toggle reveal the children                        
                            this.toggleReveal(bulkListChildren,{duration: 200, styles: ['border']});
                            // switch classes to active
                            $$(_this.minima.getElement('#bulkActions > a:first-child'), _this).switchClass('active', 'inactive');
                        },
                        'outerClick': function(){
                            // hide the children
                            bulkListChildren.dissolve({duration: 250});
                            // remove the classes to inactive
                            _this.minima.getElement('#bulkActions > a:first-child').set('class','inactive');
                        }
                    }
                }),
                // parent <a>                
                bulkListAnchor = new Element('a[text= '+ this.options.label +']'),
                // arrow <span>
                spanArrow = new Element('span.arrow');                

            // sort the list alphabetically
            this.bulkActionsArray = this.bulkActionsArray.sort(function (a, b) {
                if ( a.get("text").toLowerCase() < b.get("text").toLowerCase() ) return -1;
                if ( a.get("text").toLowerCase() == b.get("text").toLowerCase() ) return 0;
                return 1;
            });

            // then add the list items
            this.bulkActionsArray.each(function(item, index) {
                // grab the action item into the list
                bulkListChildren.grab(item);
            });

            // add the new parent <li>
            // check if there's a #toolbar-new button, the #actions goes right after that
            var liLocation = ( $('toolbar-new') ) ? 'ul > li#toolbar-new' : 'ul > li';

            // inject the new bulk <li> element after according to liLocation
            bulkListParent.inject($('toolbar').getElement(liLocation), 'after');
            
            // add the new anchor and the ul children            
            bulkListParent.adopt(bulkListAnchor.grab(spanArrow), bulkListChildren);

        } // end bulkActions.lenght     
    } // end of fixToolbar

});/** 
 * @package     Minima
 * @author      Júlio Pontes
 * @author      Marco Barbosa
 * @copyright   Copyright (C) 2011 Júlio Pontes. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

var MinimaWidgetsClass = new Class({

    Implements: [Options],

    storage: null,
    
    options: {},

    // minima node
    minima : null,
    spinner: null,
    timeout: 0,

    // columns elements caching
    columns: {},
    // boxes elements caching
    boxes: {},
    
    initialize: function() {        
        // reset the localStorage
        //localStorage.clear();
        // set the main node for DOM selection
        this.minima = document.id(this.options.minima) || document.id('minima');
        // save the columns for caching
        this.columns = this.minima.getElements('.col');
        // if we have any column to work with..
        if (this.columns.length) {
            // create a spinner element
            this.spinner = new Spinner( document.id('content-cpanel') );
            // show the spinner
            this.spinner.show(true);
            // cache the boxes elements
            this.boxes = this.minima.getElements('.box');            
            // initialize LocalStorage
            this.storage = new LocalStorage();
            // load and prepare the saved positions
            this.loadPositions();
            // add widgets events
            // disabled - no menus for now!
            //this.addEvents();
            // attach the drag and drop events
            this.attachDrag();            
        } 
    },
    
    addEvents: function() {
        var that = this;
        this.boxes.each(function(widget){
            widgetId = widget.id.replace('widget-','');
            widget.getElement('a.nav-settings').addEvent('click',function(){
                that.settings(widgetId);
            });
            widget.getElement('a.nav-hide').addEvent('click',function(){
                if(widget.hasClass('expand')){
                    widget.removeClass('expand');
                    widget.addClass('minimize');
                    this.set('text','Show');
                }
                else if(widget.hasClass('minimize')){
                    widget.removeClass('minimize');
                    widget.addClass('expand');
                    this.set('text','Hide');
                }
            });
        });
    },
    
    loadPositions: function() {
        // get widgets from the storage
        widgets = this.storage.get('widgets');
        // get out if it's not set
        
        // storage at first time
        if (typeOf(widgets) == 'array' && widgets.length === 0) this.storagePositions();        
        
        if (typeOf(widgets) == 'array')
        {
            // show the loading spinner
            // loop through each column and fix it
            this.columns.each(function(position){
                widgets.each(function(widget, index){
                    if (widget.position == position.id) {
                        if( widget.id != "" )
                            $(position.id).grab($(widget.id));
                    }
                });
            });
        } else {
            // loop through each column and fix it
            var positionIndex = 0;
            var that = this;
            $$('.box').each(function(widgetElement, index){
                that.columns[positionIndex].grab(widgetElement);
                positionIndex++;
                if(positionIndex >= that.columns.length) positionIndex = 0;
            });
        }
        // all done, show them
        // hide the spinner
        this.spinner.hide(true); 
        // display the widgets one by one
        this.displayWidgets();
    },

    // animates the transition
    displayWidgets: function() {                
        // fade in the boxes
        this.boxes.each(function(el, i) {
            setTimeout(function() {                
                el.fade('in');
            }, 300 * (i * 1.5));
        });
    },
    
    storagePositions: function() {
        // ordernation array
        ordernation = new Array(); 
        this.columns.each(function(position){
            position.getElements('.box').each(function(widget, index){
                var widgetObj = {'id': widget.id,'order': index,'position': position.id};
                ordernation.push(widgetObj);
            });
        });
        this.storage.set('widgets',ordernation);
    },
    // attach the drag and drop events
    attachDrag: function(){
        var that = this;
        // create new sortables
        new Sortables( this.columns, {
            clone : true,
            handle : '.box-top',
            opacity: 0.6,
            revert: {
                duration: 500,
                trasition: 'elastic:out'
            },
            onStart: function() {
                // add class to body to tell it's dragging
                minima.addClass('onDrag');
            },
            onComplete: function(widget) {
                // not dragging anymore
                minima.removeClass('onDrag');
                // save the positions after dropping
                that.storagePositions();
            }
        });
    },
    
    // Config action to open a modal configuration of a module
    settings: function(id) {
        var url = 'index.php?option=com_modules&client_id=0&task=module.edit&id='+id+'&tmpl=component&view=module&layout=modal';
        SqueezeBox.open(url,{handler: 'iframe', size: {x: 900, y: 550}});
    }
    
});

window.addEvent('domready', function() {
    var MinimaWidgets = new MinimaWidgetsClass();
});/**
    Head JS     The only script in your <HEAD>
    Copyright   Tero Piirainen (tipiirai)
    License     MIT / http://bit.ly/mit-license
    Version     0.96

    http://headjs.com
*/(function(a){function l(){var a=window.outerWidth||b.clientWidth;b.className=b.className.replace(/ (w|lt)-\d+/g,""),f("w-"+Math.round(a/100)*100),h(c.screens,function(b){a<=b&&f("lt-"+b)}),i.feature()}function h(a,b){for(var c=0,d=a.length;c<d;c++)b.call(a,a[c],c)}function g(a){var c=new RegExp("\\b"+a+"\\b");b.className=b.className.replace(c,"")}function f(a){d[d.length]=a}var b=a.documentElement,c={screens:[320,480,640,768,1024,1280,1440,1680,1920],section:"-section",page:"-page",head:"head"},d=[];if(window.head_conf)for(var e in head_conf)head_conf[e]!==undefined&&(c[e]=head_conf[e]);var i=window[c.head]=function(){i.ready.apply(null,arguments)};i.feature=function(a,c,e){if(!a)b.className+=" "+d.join(" "),d=[];else{Object.prototype.toString.call(c)=="[object Function]"&&(c=c.call()),f((c?"":"no-")+a),i[a]=!!c,e||(g("no-"+a),g(a),i.feature());return i}};var j=navigator.userAgent.toLowerCase();j=/(webkit)[ \/]([\w.]+)/.exec(j)||/(opera)(?:.*version)?[ \/]([\w.]+)/.exec(j)||/(msie) ([\w.]+)/.exec(j)||!/compatible/.test(j)&&/(mozilla)(?:.*? rv:([\w.]+))?/.exec(j)||[],j[1]=="msie"&&(j[1]="ie",j[2]=document.documentMode||j[2]),f(j[1]),i.browser={version:j[2]},i.browser[j[1]]=!0;if(i.browser.ie){f("ie"+parseFloat(j[2]));for(var k=3;k<11;k++)parseFloat(j[2])<k&&f("lt-ie"+k);h("abbr|article|aside|audio|canvas|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video".split("|"),function(b){a.createElement(b)})}h(location.pathname.split("/"),function(a,d){if(this.length>2&&this[d+1]!==undefined)d&&f(this.slice(1,d+1).join("-")+c.section);else{var e=a||"index",g=e.indexOf(".");g>0&&(e=e.substring(0,g)),b.id=e+c.page,d||f("root"+c.section)}}),l(),window.onresize=l,i.feature("js",!0).feature()})(document),function(){function h(a){var b=a.charAt(0).toUpperCase()+a.substr(1),c=(a+" "+d.join(b+" ")+b).split(" ");return!!g(c)}function g(a){for(var c in a)if(b[a[c]]!==undefined)return!0}var a=document.createElement("i"),b=a.style,c=" -o- -moz- -ms- -webkit- -khtml- ".split(" "),d="Webkit Moz O ms Khtml".split(" "),e=window.head_conf&&head_conf.head||"head",f=window[e],i={gradient:function(){var a="background-image:",d="gradient(linear,left top,right bottom,from(#9f9),to(#fff));",e="linear-gradient(left top,#eee,#fff);";b.cssText=(a+c.join(d+a)+c.join(e+a)).slice(0,-a.length);return!!b.backgroundImage},rgba:function(){b.cssText="background-color:rgba(0,0,0,0.5)";return!!b.backgroundColor},opacity:function(){return a.style.opacity===""},textshadow:function(){return b.textShadow===""},multiplebgs:function(){b.cssText="background:url(//:),url(//:),red url(//:)";return(new RegExp("(url\\s*\\(.*?){3}")).test(b.background)},boxshadow:function(){return h("boxShadow")},borderimage:function(){return h("borderImage")},borderradius:function(){return h("borderRadius")},cssreflections:function(){return h("boxReflect")},csstransforms:function(){return h("transform")},csstransitions:function(){return h("transition")},fontface:function(){var a=navigator.userAgent,b;if(0)return!0;if(b=a.match(/Chrome\/(\d+\.\d+\.\d+\.\d+)/))return b[1]>="4.0.249.4"||1*b[1].split(".")[0]>5;if((b=a.match(/Safari\/(\d+\.\d+)/))&&!/iPhone/.test(a))return b[1]>="525.13";if(/Opera/.test({}.toString.call(window.opera)))return opera.version()>="10.00";if(b=a.match(/rv:(\d+\.\d+\.\d+)[^b].*Gecko\//))return b[1]>="1.9.1";return!1}};for(var j in i)i[j]&&f.feature(j,i[j].call(),!0);f.feature()}(),function(a){function z(){d||(d=!0,s(e,function(a){p(a)}))}function y(c,d){var e=a.createElement("script");e.type="text/"+(c.type||"javascript"),e.src=c.src||c,e.async=!1,e.onreadystatechange=e.onload=function(){var a=e.readyState;!d.done&&(!a||/loaded|complete/.test(a))&&(d.done=!0,d())},(a.body||b).appendChild(e)}function x(a,b){if(a.state==o)return b&&b();if(a.state==n)return k.ready(a.name,b);if(a.state==m)return a.onpreload.push(function(){x(a,b)});a.state=n,y(a.url,function(){a.state=o,b&&b(),s(g[a.name],function(a){p(a)}),u()&&d&&s(g.ALL,function(a){p(a)})})}function w(a,b){a.state===undefined&&(a.state=m,a.onpreload=[],y({src:a.url,type:"cache"},function(){v(a)}))}function v(a){a.state=l,s(a.onpreload,function(a){a.call()})}function u(a){a=a||h;var b;for(var c in a){if(a.hasOwnProperty(c)&&a[c].state!=o)return!1;b=!0}return b}function t(a){return Object.prototype.toString.call(a)=="[object Function]"}function s(a,b){if(!!a){typeof a=="object"&&(a=[].slice.call(a));for(var c=0;c<a.length;c++)b.call(a,a[c],c)}}function r(a){var b;if(typeof a=="object")for(var c in a)a[c]&&(b={name:c,url:a[c]});else b={name:q(a),url:a};var d=h[b.name];if(d&&d.url===b.url)return d;h[b.name]=b;return b}function q(a){var b=a.split("/"),c=b[b.length-1],d=c.indexOf("?");return d!=-1?c.substring(0,d):c}function p(a){a._done||(a(),a._done=1)}var b=a.documentElement,c,d,e=[],f=[],g={},h={},i=a.createElement("script").async===!0||"MozAppearance"in a.documentElement.style||window.opera,j=window.head_conf&&head_conf.head||"head",k=window[j]=window[j]||function(){k.ready.apply(null,arguments)},l=1,m=2,n=3,o=4;i?k.js=function(){var a=arguments,b=a[a.length-1],c={};t(b)||(b=null),s(a,function(d,e){d!=b&&(d=r(d),c[d.name]=d,x(d,b&&e==a.length-2?function(){u(c)&&p(b)}:null))});return k}:k.js=function(){var a=arguments,b=[].slice.call(a,1),d=b[0];if(!c){f.push(function(){k.js.apply(null,a)});return k}d?(s(b,function(a){t(a)||w(r(a))}),x(r(a[0]),t(d)?d:function(){k.js.apply(null,b)})):x(r(a[0]));return k},k.ready=function(b,c){if(b==a){d?p(c):e.push(c);return k}t(b)&&(c=b,b="ALL");if(typeof b!="string"||!t(c))return k;var f=h[b];if(f&&f.state==o||b=="ALL"&&u()&&d){p(c);return k}var i=g[b];i?i.push(c):i=g[b]=[c];return k},k.ready(a,function(){u()&&s(g.ALL,function(a){p(a)}),k.feature&&k.feature("domloaded",!0)});if(window.addEventListener)a.addEventListener("DOMContentLoaded",z,!1),window.addEventListener("load",z,!1);else if(window.attachEvent){a.attachEvent("onreadystatechange",function(){a.readyState==="complete"&&z()});var A=1;try{A=window.frameElement}catch(B){}!A&&b.doScroll&&function(){try{b.doScroll("left"),z()}catch(a){setTimeout(arguments.callee,1);return}}(),window.attachEvent("onload",z)}!a.readyState&&a.addEventListener&&(a.readyState="loading",a.addEventListener("DOMContentLoaded",handler=function(){a.removeEventListener("DOMContentLoaded",handler,!1),a.readyState="complete"},!1)),setTimeout(function(){c=!0,s(f,function(a){a()})},300)}(document)/*
---
description: A cross browser persistent storgae API

license: MIT-style

authors:
- Arieh Glazer

requires:
- core/1.2.4 : [Core,Class,Class.Extras,Cookie]

provides: [LocalStorage]

...
*/
/*!
Copyright (c) 2010 Arieh Glazer

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE 
*/
(function($,window,undef){

var LocalStorage = this.LocalStorage = new Class({
    Implements : [Options]
    , options : {
          path : '*'
        , name : window.location.hostname
        , duration : 60*60*24*30
        , debug : false
    }
    , storage : null
    , initialize : function(options){
         var $this = this;
         
         this.setOptions(options);
         
         if (window.localStorage){ //HTML5 storage
            if (this.options.debug) console.log('using localStorage')
            this.storage = window.localStorage;
         }else if (Browser.Engine.trident){ //IE < 8
                if (this.options.debug) console.log('using behavior Storage');
            	this.storage = (function(){
                    var storage = document.createElement("span");
                    storage.style.behavior = "url(#default#userData)";
                    $(document.body).adopt(storage);  
                    storage.load($this.options.name);
                    
                    return {
                        setItem : function(name,value){
                            storage.setAttribute(name,value);
                            storage.save($this.options.name);
                        }
                        , getItem : function (name){
                            return storage.getAttribute(name);
                        }
                        , removeItem : function(name){
                            storage.removeAttribute(name);
                            storage.save($this.options.name);
                        }
                    };
                })();
         }else if (window.globalStorage){ //FF<3.5
            if (this.options.debug) console.log('using globalStorage');
            this.storage = (function(){
                storage = globalStorage[$this.options.name];
                return {
                        setItem : function(name,value){
                            storage[name] = value;
                        }
                        , getItem : function (name){
                            return ('value' in storage[name]) ? storage[name].value : null;
                        }
                        , removeItem : function(name){
                            delete(storage[name]);
                        }
                    };
            })();
         }else{ //All others
            if (this.options.debug) console.log('using cookies');
            this.storage = (function(){
                var options ={
                    path : $this.options.path
                    , duration : $this.options.duration
                };
                
                return {
                        setItem : function(name,value){
                             Cookie.write(name,value,options);
                        }
                        , getItem : function (name){
                             return Cookie.read(name);
                        }
                        , removeItem : function(name){
                             Cookie.dispose(name);
                        }
                    };
            })();
         }
    },
    set : function(name,value){
        this.storage.setItem(name,JSON.encode(value));
        return this;
    }
    , get : function (name){
        
        return JSON.decode(this.storage.getItem(name));
    }
    , remove : function (name){
        this.storage.removeItem(name);
        return this;
    }
});

})(document.id,this);/*!
 * selectivizr v1.0.1 - (c) Keith Clark, freely distributable under the terms of the MIT license.
 * selectivizr.com
 */
var k=true,p=false;(function(A){function N(a){return a.replace(O,q).replace(P,function(b,e,c){b=c.split(",");c=0;for(var g=b.length;c<g;c++){var h=Q(b[c].replace(R,q).replace(S,q))+w,f=[];b[c]=h.replace(T,function(d,l,m,j,i){if(l){if(f.length>0){d=f;var x;i=h.substring(0,i).replace(U,o);if(i==o||i.charAt(i.length-1)==w)i+="*";try{x=y(i)}catch(ha){}if(x){i=0;for(m=x.length;i<m;i++){j=x[i];for(var B=j.className,C=0,V=d.length;C<V;C++){var r=d[C];if(!RegExp("(^|\\s)"+r.className+"(\\s|$)").test(j.className))if(r.b&&(r.b===k||r.b(j)===k))B=E(B,r.className,k)}j.className=B}}f=[]}return l}else{if(l=m?W(m):!F||F.test(j)?{className:G(j),b:k}:null){f.push(l);return"."+l.className}return d}})}return e+b.join(",")})}function W(a){var b=k,e=G(a.slice(1)),c=a.substring(0,5)==":not(",g,h;if(c)a=a.slice(5,-1);var f=a.indexOf("(");if(f>-1)a=a.substring(0,f);if(a.charAt(0)==":")switch(a.slice(1)){case "root":b=function(d){return c?d!=H:d==H};break;case "target":if(s==8){b=function(d){function l(){var m=location.hash,j=m.slice(1);return c?m==""||d.id!=j:m!=""&&d.id==j}t(A,"hashchange",function(){u(d,e,l())});return l()};break}return p;case "checked":b=function(d){X.test(d.type)&&t(d,"propertychange",function(){event.propertyName=="checked"&&u(d,e,d.checked!==c)});return d.checked!==c};break;case "disabled":c=!c;case "enabled":b=function(d){if(Y.test(d.tagName)){t(d,"propertychange",function(){event.propertyName=="$disabled"&&u(d,e,d.a===c)});z.push(d);d.a=d.disabled;return d.disabled===c}return a==":enabled"?c:!c};break;case "focus":g="focus";h="blur";case "hover":if(!g){g="mouseenter";h="mouseleave"}b=function(d){t(d,c?h:g,function(){u(d,e,k)});t(d,c?g:h,function(){u(d,e,p)});return c};break;default:if(!Z.test(a))return p}return{className:e,b:b}}function G(a){return I+"-"+(s==6&&$?aa++:a.replace(ba,function(b){return b.charCodeAt(0)}))}function Q(a){return a.replace(J,q).replace(ca,w)}function u(a,b,e){var c=a.className;b=E(c,b,e);if(b!=c){a.className=b;a.parentNode.className+=o}}function E(a,b,e){var c=RegExp("(^|\\s)"+b+"(\\s|$)"),g=c.test(a);return e?g?a:a+w+b:g?a.replace(c,q).replace(J,q):a}function t(a,b,e){a.attachEvent("on"+b,e)}function D(a,b){if(/^https?:\/\//i.test(a))return b.substring(0,b.indexOf("/",8))==a.substring(0,a.indexOf("/",8))?a:null;if(a.charAt(0)=="/")return b.substring(0,b.indexOf("/",8))+a;var e=b.split("?")[0];if(a.charAt(0)!="?"&&e.charAt(e.length-1)!="/")e=e.substring(0,e.lastIndexOf("/")+1);return e+a}function K(a){if(a){v.open("GET",a,p);v.send();return(v.status==200?v.responseText:o).replace(da,o).replace(ea,function(b,e,c,g,h){return K(D(c||h,a))}).replace(fa,function(b,e,c){e=e||"";return" url("+e+D(c,a)+e+") "})}return o}function ga(){var a,b;a=n.getElementsByTagName("BASE");for(var e=a.length>0?a[0].href:n.location.href,c=0;c<n.styleSheets.length;c++){b=n.styleSheets[c];if(b.href!=o)if(a=D(b.href,e))b.cssText=N(K(a))}z.length>0&&setInterval(function(){for(var g=0,h=z.length;g<h;g++){var f=z[g];if(f.disabled!==f.a)if(f.disabled){f.disabled=p;f.a=k;f.disabled=k}else f.a=f.disabled}},250)}if(!/*@cc_on!@*/true){var n=document,H=n.documentElement,v=function(){if(A.XMLHttpRequest)return new XMLHttpRequest;try{return new ActiveXObject("Microsoft.XMLHTTP")}catch(a){return null}}(),s=/MSIE ([\d])/.exec(navigator.userAgent)[1];if(!(n.compatMode!="CSS1Compat"||s<6||s>8||!v)){var L={NW:"*.Dom.select",DOMAssistant:"*.$",Prototype:"$$",YAHOO:"*.util.Selector.query",MooTools:"$$",Sizzle:"*",jQuery:"*",dojo:"*.query"},y,z=[],aa=0,$=k,I="slvzr",M=I+"DOMReady",da=/(\/\*[^*]*\*+([^\/][^*]*\*+)*\/)\s*/g,ea=/@import\s*(?:(?:(?:url\(\s*(['"]?)(.*)\1)\s*\))|(?:(['"])(.*)\3))[^;]*;/g,fa=/\burl\(\s*(["']?)([^"')]+)\1\s*\)/g,Z=/^:(empty|(first|last|only|nth(-last)?)-(child|of-type))$/,O=/:(:first-(?:line|letter))/g,P=/(^|})\s*([^\{]*?[\[:][^{]+)/g,T=/([ +~>])|(:[a-z-]+(?:\(.*?\)+)?)|(\[.*?\])/g,U=/(:not\()?:(hover|enabled|disabled|focus|checked|target|active|visited|first-line|first-letter)\)?/g,ba=/[^\w-]/g,Y=/^(INPUT|SELECT|TEXTAREA|BUTTON)$/,X=/^(checkbox|radio)$/,F=s>6?/[\$\^*]=(['"])\1/:null,R=/([(\[+~])\s+/g,S=/\s+([)\]+~])/g,ca=/\s+/g,J=/^\s*((?:[\S\s]*\S)?)\s*$/,o="",w=" ",q="$1";n.write("<script id="+M+" defer src='//:'><\/script>");n.getElementById(M).onreadystatechange=function(){if(this.readyState=="complete"){a:{var a,b;for(b in L)if(A[b]&&(a=eval(L[b].replace("*",b)))){y=a;break a}y=p}if(y){ga();this.parentNode.removeChild(this)}}}}}})(this);/** 
 * @package			Minima
 * @author			Marco Barbosa
 * @contributors	Henrik Hussfelt
 * @copyright		Copyright (C) 2010 Marco Barbosa. All rights reserved.
 * @license			GNU General Public License version 2 or later; see LICENSE.txt
 */

// EXTRAS
// ==================================================
// outerClick function
(function(){var b;var a=function(f){var d=$(f.target);var c=d.getParents();b.each(function(g){var e=g.element;if(e!=d&&!c.contains(e)){g.fn.call(e,f)}})};Element.Events.outerClick={onAdd:function(c){if(!b){document.addEvent("click",a);b=[]}b.push({element:this,fn:c})},onRemove:function(c){b=b.filter(function(d){return d.element!=this||d.fn!=c},this);if(!b.length){document.removeEvent("click",a);b=null}}}})();

// switchClass function
Element.implement('switchClass', function(a, b){ var toggle = this.hasClass(a); this.removeClass(toggle ? a : b).addClass(toggle ? b : a); return this; });

// extending Selector for a visible boolean
$extend(Selectors.Pseudo,{visible:function(){if(this.getStyle("visibility")!="hidden"&&this.isVisible()&&this.isDisplayed()){return this}}});

// toggle for reveal or dissolve
Element.implement('toggleReveal', function(el, options) {
    return el.isDisplayed() ? el.dissolve(options) : el.reveal(options);
});

// PLUGINS
// ==================================================
// ScrollSpy by David Walsh (http://davidwalsh.name/js/scrollspy)
var ScrollSpy=new Class({Implements:[Options,Events],options:{container:window,max:0,min:0,mode:"vertical"},initialize:function(a){this.setOptions(a);this.container=document.id(this.options.container);this.enters=this.leaves=0;this.inside=false;this.listener=function(d){var b=this.container.getScroll(),c=b[this.options.mode=="vertical"?"y":"x"];if(c>=this.options.min&&(this.options.max==0||c<=this.options.max)){if(!this.inside){this.inside=true;this.enters++;this.fireEvent("enter",[b,this.enters,d])}this.fireEvent("tick",[b,this.inside,this.enters,this.leaves,d])}else{if(this.inside){this.inside=false;this.leaves++;this.fireEvent("leave",[b,this.leaves,d])}}this.fireEvent("scroll",[b,this.inside,this.enters,this.leaves,d])};this.addListener()},start:function(){this.container.addEvent("scroll",this.listener.bind(this))},stop:function(){this.container.removeEvent("scroll",this.listener.bind(this))},addListener:function(){this.start()}});

// DOMREADY
window.addEvent('domready', function() {

    // Initiate some global variables
    // -------------------------------     
    var 
        // get the language strings
        language        = MooTools.lang.get('Minima');
        // DOM variables                
        contentTop      = $('content-top'),
        toolbar         = $('toolbar'),
        topHead         = $('tophead'),
        minima          = $('minima'),
        subMenu         = $('submenu'),
        itemForm        = $('item-form'),
        filterBar       = $('filter-bar'),
        // Initiate MimimaClass
        Minima          = new MinimaClass({},{
                                  systemMessage : $('system-message'),
                                  jformTitle    : $('jform_title')
                              }),
        // Initiate MinimaToolbar
        MinimaToolbar   = new MinimaToolbarClass({
                                  'toolbar'         : toolbar, // toolbar parent
                                  'toolbarElements' : minima.getElements('.toolbar-list li a'), // list of the anchor elements
                                  'label'           : language['actionBtn']
                              }),
        MinimaFilterBar = new MinimaFilterBarClass({}, {
                                  'filterBar' : filterBar
                              }, {
                                  'hideFilter' : language['hideFilter'],
                                  'showFilter' : language['showFilter']
                              })
    ;

    // ------------------------------- 

    // TRIGGERS
    // =============================    
    // smooth scroll when clicking "back to top"
    new Fx.SmoothScroll({
        links: '#topLink'
    });    

    // fix the filterbar
    if (filterBar) {        
        MinimaFilterBar.doFilterBar();
    }

    // Show system message (if applicable)
    Minima.showSystemMessage();

    // make title dynamic if we have one
    if ($('jform_title')) {
        Minima.dynamicTitle();
    };

    // Make whole row clickable, if there are any    
    if (minima.getElements('.adminlist').length) {
    	Minima.makeRowsClickable();
    };

    // TOOLBAR
    // =============================
    // fix the toolbar
    MinimaToolbar.doToolbar();

    // show it afterwards
    if (toolbar) {
        toolbar.show();
    };

    // TABS
    // =============================
    if (subMenu && itemForm) {
        
        // Start tabs actions, create instances of class
    	var MinimaTabsHorizontal = new MinimaTabsClass({}, {
                'tabs'    : subMenu.getElements('a'), 
                'content' : itemForm.getChildren('div')
            }),
        MinimaTabsVertical = new MinimaTabsClass({}, {
                'tabs'    : minima.getElements('.vertical-tabs a'), 
                'content' : $('tabs').getChildren('.panelform')
            });

        if (subMenu.hasClass('out')) {
            MinimaTabsHorizontal.moveTabs(subMenu);   
        }

    	// Add tabs for horizontal submenu
        // Hide all content elements
        MinimaTabsHorizontal.hideAllContent();
        // Show the first
        MinimaTabsHorizontal.showFirst();
        // Add onClick
        MinimaTabsHorizontal.addTabsAction();

        // Add tabs for vertical menu
        // Hide all content elements
        MinimaTabsVertical.hideAllContent();
        // Show the first
        MinimaTabsVertical.showFirst();
        // Add onClick
        MinimaTabsVertical.addTabsAction();
    };    

    // individual tabs, not necessairly in a form
    if (subMenu && subMenu.hasClass('out')) {
        subMenu.inject( $('content'), 'top' );
    }

    // SCROLLING
    // =============================
    // fixed content-box header when scrolling    
    var scrollSize = document.getScrollSize().y - document.getSize().y;
    
    /* scrollspy instance */    
    new ScrollSpy({
        // the minimum ammount of scrolling before it triggers
        min: 200, 
        onEnter: function() {            
            // we are in locked mode, must fix positioning
            if (scrollSize > 400) {
                if (document.body.hasClass('locked')) {
                    contentTop.setStyle('left', (topHead.getSize().x - 1140) / 2);
                };
                contentTop.setStyle('width', topHead.getSize().x - 40).addClass('fixed');
            };
        },
        onLeave: function() {
            if (scrollSize > 400) {
                contentTop.removeClass('fixed');
                if(document.body.hasClass('locked')) {
                    contentTop.setStyle('width', '100%');
                };
            };
        }
    }); 
    
    // PANEL TAB
    // ==================================================
    // tabs wrapper
    var $panelWrapper = $('panel-wrapper'),
        extra        = $('more')
        extraLists   = $('list-content'),
        openPanel    = $('panel-tab'),
        listWrapper  = $('list-wrapper');

    if ($panelWrapper) {

	    // Fixing wrapper bug
	    Fx.Slide.Mine = new Class({
	        Extends: Fx.Slide,
	        initialize: function(el, options) {
	            this.parent(el, options);
	            this.wrapper = this.element.getParent();
	        }
	    });

        // cache elements
        var $panelPagination = $('panel-pagination'),
            $prev            = $('prev'),
            $next            = $('next');

		// Create a Panel instance
		var Panel = new MinimaPanelClass({
				panelWrapper: $panelWrapper,
				prev: $prev,
				next: $next,
				panelList: $('panel-list'),
				panelPage: $panelPagination
		});

		// Setup click event for previous
		$prev.addEvent('click', function() {
			Panel.doPrevious();
		});
		// Setup click event for previous
		$next.addEvent('click', function() {
			Panel.doNext();
		});

		// Fix panel pagination
		$panelPagination.getChildren("li").addEvent('click', function() {
			// Send ID to changepage as this contains pagenumber
			Panel.changeToPage(this);
		});

        // Open the panel slide
        openPanel.addEvents({
            'click': function(){                
                //minima.getElements("#shortcuts .parent").getChildren('.sub').dissolve({duration: 200}).removeClass('hover');
                minima.getElements("#shortcuts .parent").removeClass('hover');
        		Panel.panel.toggle();
            }
        });

        // change status on toggle complete
        Panel.panel.addEvent('complete', function() {
            openPanel.set('class', Panel.panelStatus[Panel.panel.open]);
        });

        // slide up panel when clicking a link
        minima.getElements('#panel-list li').addEvent('click', function(){            
            Panel.panel.toggle();
        });

    }; // end of if($panelWrapper)


    // dropdown menu
    if (extra) {
        extra.addEvent('click', function(){            
            this.switchClass('active','inactive');            
            //extraLists.toggle();
            this.toggleReveal(extraLists, {heightOverride: '155',duration: 250});
        });
    }

    var hideLists = function() {
        extra.set('class','inactive');
        listWrapper.removeClass('active');
        extraLists.dissolve();            
    };

    // turn off list when click outside
    if (listWrapper) {
        listWrapper.addEvent('outerClick', function(){
            hideLists();
        });
    }

    // turn off list when clicking a link
    if (extraLists) {
        extraLists.getElements("a").addEvent('click', function(){
            hideLists();
        });
    }

    minima.getElements('#shortcuts .parent').each(function(li) {             
        // add events to the list elements
        li.addEvents({
           'click' : function() {                    
                // show or hide when click on the arrow                    
                this.toggleReveal(this.getChildren('.sub')[0]).toggleClass('hover');                    
                this.getElement('a').toggleClass('hover');
           },
           'outerClick' : function() {
                // hide when clicking outside or on a different element                    
                this.getChildren('.sub').dissolve({duration: 200}).removeClass('hover');
                this.getElement('a').removeClass('hover');
           }
        });            
    });

    // dashboard icons actions
    //if (minima.hasClass('com_cpanel')) {        
        // minima.getElements('.box-icon').addEvent('click', function() {        
        //     this.toggleClass('hover').getParent('nav').toggleReveal(this.getNext('ul'), { duration: 200});
        // });
        // minima.getElements('.box-icon').addEvent('outerClick', function(){
            //this.toggleClass('hover').getParent('nav').dissolve();
            //this.getParent('nav').getNext('ul').dissolve();
        // }); 
    // }
/*
    var cleanSelectedRows = function() {        
        minima.getElements('td.selected').removeClass('selected');
    }

    minima.getElements('.adminlist thead th').addEvents({        
        mouseenter : function() {
            var nColumn = this.getAllPrevious('th').length + 1;
            if (nColumn > 1) {
                cleanSelectedRows();
                minima.getElements('.adminlist td:nth-child('+nColumn+')').addClass('selected');            
            }
        },
        mouseleave : function() {
            cleanSelectedRows();            
        }
    });
*/
});
